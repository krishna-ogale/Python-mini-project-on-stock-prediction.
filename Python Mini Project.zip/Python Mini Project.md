```python
import yfinance as yf
```


```python
symbol = "AAPL"
start_date = "2022-01-01"
end_date = "2023-01-01"
```


```python
apple_stock_data = yf.download(symbol, start=start_date, end=end_date)
apple_stock_data
```

    [*********************100%%**********************]  1 of 1 completed
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>Close</th>
      <th>Adj Close</th>
      <th>Volume</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2022-01-03</th>
      <td>177.830002</td>
      <td>182.880005</td>
      <td>177.710007</td>
      <td>182.009995</td>
      <td>180.190964</td>
      <td>104487900</td>
    </tr>
    <tr>
      <th>2022-01-04</th>
      <td>182.630005</td>
      <td>182.940002</td>
      <td>179.119995</td>
      <td>179.699997</td>
      <td>177.904053</td>
      <td>99310400</td>
    </tr>
    <tr>
      <th>2022-01-05</th>
      <td>179.610001</td>
      <td>180.169998</td>
      <td>174.639999</td>
      <td>174.919998</td>
      <td>173.171829</td>
      <td>94537600</td>
    </tr>
    <tr>
      <th>2022-01-06</th>
      <td>172.699997</td>
      <td>175.300003</td>
      <td>171.639999</td>
      <td>172.000000</td>
      <td>170.281006</td>
      <td>96904000</td>
    </tr>
    <tr>
      <th>2022-01-07</th>
      <td>172.889999</td>
      <td>174.139999</td>
      <td>171.029999</td>
      <td>172.169998</td>
      <td>170.449310</td>
      <td>86709100</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2022-12-23</th>
      <td>130.919998</td>
      <td>132.419998</td>
      <td>129.639999</td>
      <td>131.860001</td>
      <td>131.299820</td>
      <td>63814900</td>
    </tr>
    <tr>
      <th>2022-12-27</th>
      <td>131.380005</td>
      <td>131.410004</td>
      <td>128.720001</td>
      <td>130.029999</td>
      <td>129.477585</td>
      <td>69007800</td>
    </tr>
    <tr>
      <th>2022-12-28</th>
      <td>129.669998</td>
      <td>131.029999</td>
      <td>125.870003</td>
      <td>126.040001</td>
      <td>125.504539</td>
      <td>85438400</td>
    </tr>
    <tr>
      <th>2022-12-29</th>
      <td>127.989998</td>
      <td>130.479996</td>
      <td>127.730003</td>
      <td>129.610001</td>
      <td>129.059372</td>
      <td>75703700</td>
    </tr>
    <tr>
      <th>2022-12-30</th>
      <td>128.410004</td>
      <td>129.949997</td>
      <td>127.430000</td>
      <td>129.929993</td>
      <td>129.378006</td>
      <td>77034200</td>
    </tr>
  </tbody>
</table>
<p>251 rows × 6 columns</p>
</div>



 Perform Cleaning


```python
print(apple_stock_data.head())
```

                      Open        High         Low       Close   Adj Close  \
    Date                                                                     
    2022-01-03  177.830002  182.880005  177.710007  182.009995  180.190964   
    2022-01-04  182.630005  182.940002  179.119995  179.699997  177.904053   
    2022-01-05  179.610001  180.169998  174.639999  174.919998  173.171829   
    2022-01-06  172.699997  175.300003  171.639999  172.000000  170.281006   
    2022-01-07  172.889999  174.139999  171.029999  172.169998  170.449310   
    
                   Volume  
    Date                   
    2022-01-03  104487900  
    2022-01-04   99310400  
    2022-01-05   94537600  
    2022-01-06   96904000  
    2022-01-07   86709100  
    


```python
print(apple_stock_data.isnull().sum())
```

    Open         0
    High         0
    Low          0
    Close        0
    Adj Close    0
    Volume       0
    dtype: int64
    

Chnage in stock price over time:


```python
# Calculate daily price changes
apple_stock_data['PriceChange'] = apple_stock_data['Volume'].diff()

# Calculate cumulative price changes over time
apple_stock_data['CumulativePriceChange'] = apple_stock_data['PriceChange'].cumsum()

# Print the resulting DataFrame
print(apple_stock_data[['Volume', 'PriceChange', 'CumulativePriceChange']].head(20))

```

                   Volume  PriceChange  CumulativePriceChange
    Date                                                     
    2022-01-03  104487900          NaN                    NaN
    2022-01-04   99310400   -5177500.0             -5177500.0
    2022-01-05   94537600   -4772800.0             -9950300.0
    2022-01-06   96904000    2366400.0             -7583900.0
    2022-01-07   86709100  -10194900.0            -17778800.0
    2022-01-10  106765600   20056500.0              2277700.0
    2022-01-11   76138300  -30627300.0            -28349600.0
    2022-01-12   74805200   -1333100.0            -29682700.0
    2022-01-13   84505800    9700600.0            -19982100.0
    2022-01-14   80440800   -4065000.0            -24047100.0
    2022-01-18   90956700   10515900.0            -13531200.0
    2022-01-19   94815000    3858300.0             -9672900.0
    2022-01-20   91420500   -3394500.0            -13067400.0
    2022-01-21  122848900   31428400.0             18361000.0
    2022-01-24  162294600   39445700.0             57806700.0
    2022-01-25  115798400  -46496200.0             11310500.0
    2022-01-26  108275300   -7523100.0              3787400.0
    2022-01-27  121954600   13679300.0             17466700.0
    2022-01-28  179935700   57981100.0             75447800.0
    2022-01-31  115541600  -64394100.0             11053700.0
    

Visualize the change in a stock’s volume being traded, over time


```python
import matplotlib.pyplot as plt


plt.figure(figsize=(12, 6))
plt.plot(apple_stock_data.index, apple_stock_data['Adj Close'], label='Adj Close', color='blue')
plt.title('Apple Inc. (AAPL) Trading Volume Over Time')
plt.xlabel('Date')
plt.ylabel('Adj Close')
plt.grid(True,linestyle=":",color="g")
plt.legend()
plt.show()

```


    
![png](output_9_0.png)
    


What was the daily return average of a stock


```python
import yfinance as yf
import pandas as pd

# Define the ticker symbol for the stock you want to analyze
ticker_symbol = 'AAPL'  # Example: Apple

# Download historical stock data
stock_data = yf.download(ticker_symbol, start='2020-01-01', end='2023-01-01')

# Calculate the daily returns
stock_data['DailyReturn'] = stock_data['Close'].pct_change()

# Calculate the average daily return
average_daily_return = stock_data['DailyReturn'].mean()

print(f"Average Daily Return for {ticker_symbol}: {average_daily_return:.5f}")

```

    [*********************100%%**********************]  1 of 1 completed
    Average Daily Return for AAPL: 0.00100
    

Adda new column ‘Trend’ whose values are based on the 'Daily Return


```python
# Define the ticker symbol for the stock you want to analyze
ticker_symbol = 'AAPL'  # Example: Apple

# Download historical stock data
stock_data = yf.download(ticker_symbol, start='2020-01-01', end='2023-01-01')

# Calculate the daily returns
stock_data['DailyReturn'] = stock_data['Close'].pct_change()

# Define a threshold for the trend (e.g., 0.0 for no change)
trend_threshold = 0.0

# Add a 'Trend' column based on the 'DailyReturn'
stock_data['Trend'] = 'No Change'  # Default to 'No Change'
stock_data.loc[stock_data['DailyReturn'] > trend_threshold, 'Trend'] = 'Upward'
stock_data.loc[stock_data['DailyReturn'] < -trend_threshold, 'Trend'] = 'Downward'

# Print the resulting DataFrame
print(stock_data[['Close', 'DailyReturn', 'Trend']].head(40))

```

    [*********************100%%**********************]  1 of 1 completed
                    Close  DailyReturn      Trend
    Date                                         
    2020-01-02  75.087502          NaN  No Change
    2020-01-03  74.357498    -0.009722   Downward
    2020-01-06  74.949997     0.007968     Upward
    2020-01-07  74.597504    -0.004703   Downward
    2020-01-08  75.797501     0.016086     Upward
    2020-01-09  77.407501     0.021241     Upward
    2020-01-10  77.582497     0.002261     Upward
    2020-01-13  79.239998     0.021364     Upward
    2020-01-14  78.169998    -0.013503   Downward
    2020-01-15  77.834999    -0.004286   Downward
    2020-01-16  78.809998     0.012526     Upward
    2020-01-17  79.682503     0.011071     Upward
    2020-01-21  79.142502    -0.006777   Downward
    2020-01-22  79.425003     0.003570     Upward
    2020-01-23  79.807503     0.004816     Upward
    2020-01-24  79.577499    -0.002882   Downward
    2020-01-27  77.237503    -0.029405   Downward
    2020-01-28  79.422501     0.028289     Upward
    2020-01-29  81.084999     0.020932     Upward
    2020-01-30  80.967499    -0.001449   Downward
    2020-01-31  77.377502    -0.044339   Downward
    2020-02-03  77.165001    -0.002746   Downward
    2020-02-04  79.712502     0.033014     Upward
    2020-02-05  80.362503     0.008154     Upward
    2020-02-06  81.302498     0.011697     Upward
    2020-02-07  80.007500    -0.015928   Downward
    2020-02-10  80.387497     0.004750     Upward
    2020-02-11  79.902496    -0.006033   Downward
    2020-02-12  81.800003     0.023748     Upward
    2020-02-13  81.217499    -0.007121   Downward
    2020-02-14  81.237503     0.000246     Upward
    2020-02-18  79.750000    -0.018311   Downward
    2020-02-19  80.904999     0.014483     Upward
    2020-02-20  80.074997    -0.010259   Downward
    2020-02-21  78.262497    -0.022635   Downward
    2020-02-24  74.544998    -0.047500   Downward
    2020-02-25  72.019997    -0.033872   Downward
    2020-02-26  73.162498     0.015864     Upward
    2020-02-27  68.379997    -0.065368   Downward
    2020-02-28  68.339996    -0.000585   Downward
    

Visualize trend frequency through a Pie Chart.


```python


# Define the ticker symbol for the stock you want to analyze
ticker_symbol = 'AAPL'  # Example: Apple

# Download historical stock data
stock_data = yf.download(ticker_symbol, start='2020-01-01', end='2023-01-01')

# Calculate the daily returns
stock_data['DailyReturn'] = stock_data['Close'].pct_change()

# Define a threshold for the trend (e.g., 0.0 for no change)
trend_threshold = 0.0

# Add a 'Trend' column based on the 'DailyReturn'
stock_data['Trend'] = 'No Change'  # Default to 'No Change'
stock_data.loc[stock_data['DailyReturn'] > trend_threshold, 'Trend'] = 'Upward'
stock_data.loc[stock_data['DailyReturn'] < -trend_threshold, 'Trend'] = 'Downward'

# Create a DataFrame to count trend frequencies
trend_counts = stock_data['Trend'].value_counts()

# Create a pie chart to visualize trend frequencies
plt.figure(figsize=(8, 8))
plt.pie(trend_counts, labels=trend_counts.index, autopct='%1.1f%%', startangle=140)
plt.title(f'Trend Frequencies for {ticker_symbol}')
plt.show()

```

    [*********************100%%**********************]  1 of 1 completed
    


    
![png](output_15_1.png)
    



```python

```


```python

```
